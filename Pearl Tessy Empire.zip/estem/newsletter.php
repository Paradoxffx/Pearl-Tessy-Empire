<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load PHPMailer

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["message" => "❌ Invalid email address!"]);
        exit;
    }

    // File where emails are stored
    $file = "subscribers.txt";

    // Check if email already exists
    if (file_exists($file)) {
        $subscribers = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (in_array($email, $subscribers)) {
            echo json_encode(["message" => "⚠️ This email is already subscribed!"]);
            exit;
        }
    }

    // Save email to the file (since it does not exist)
    file_put_contents($file, $email . PHP_EOL, FILE_APPEND);

    // PHPMailer setup
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Use Gmail SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'olatunbosunmarvelous545@gmail.com; // Your Gmail
        $mail->Password = 'zwgu dare vsqo iutu'; // Generate an App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Email details
        $mail->setFrom('etamesoremike@yahoo.com', 'VRT Newsletter');
        $mail->addAddress('etamesoremike@yahoo.com'); // Your email
        $mail->Subject = 'New Newsletter Subscription';
        $mail->Body = "New subscriber: $email";

        // Send email
        $mail->send();

        // Send WhatsApp Message
        $whatsappMessage = urlencode("New Newsletter Subscription!\nEmail: $email");
        file_get_contents("https://api.callmebot.com/whatsapp.php?phone=2348143030474&text=$whatsappMessage&apikey=8106662");

        echo json_encode(["message" => "✅ Subscribed successfully!"]);
    } catch (Exception $e) {
        echo json_encode(["message" => "⚠️ Subscription failed, please try again!"]);
    }
}
?>