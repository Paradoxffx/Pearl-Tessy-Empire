<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load PHPMailer

// ✅ Ensure REQUEST_METHOD is set
if (!isset($_SERVER["REQUEST_METHOD"]) || $_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["message" => "❌ Invalid request method!"]);
    exit;
}

// Get POST data (form or JSON)
$requestBody = file_get_contents("php://input");
$data = json_decode($requestBody, true);

$name = $_POST['name'] ?? ($data['name'] ?? null);
$email = $_POST['email'] ?? ($data['email'] ?? null);
$message = $_POST['message'] ?? ($data['message'] ?? null);

// Validation
if (empty($name) || empty($email) || empty($message)) {
    echo json_encode(["message" => "❌ All fields are required!"]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["message" => "❌ Invalid email address!"]);
    exit;
}

// PHPMailer setup
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Use Gmail SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'Olatunbosunmarvelous545@gmail.com; // Your Gmail
    $mail->Password = 'zwgu dare vsqo iutu'; // App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Email details
    $mail->setFrom($email, $name);
    $mail->addAddress('etamesoremike@yahoo.com); // Your email
    $mail->Subject = "New Contact Form Message from $name";
    $mail->Body = "📩 New Message from Contact Form\n\n👤 Name: $name\n✉️ Email: $email\n📝 Message:\n$message";

    // Send email
    $mail->send();

    // Send WhatsApp Notification
    $whatsappMessage = urlencode("📩 New Contact Form Message!\n\n👤 Name: $name\n✉️ Email: $email\n📝 Message:\n$message");
    file_get_contents("https://api.callmebot.com/whatsapp.php?phone=2348143030474&text=$whatsappMessage&apikey=8106662");

    echo json_encode(["message" => "✅ Message sent successfully!"]);
} catch (Exception $e) {
    echo json_encode(["message" => "⚠️ Message sending failed, please try again!"]);
}
?>
